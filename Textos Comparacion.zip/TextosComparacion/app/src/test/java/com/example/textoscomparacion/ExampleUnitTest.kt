package com.example.textoscomparacion

import android.widget.EditText
import org.junit.Test

import org.junit.Assert.*


class ExampleUnitTest {
    @Test

    fun testCompararTextos() {

        val texto1 = <EditText>(R.id.editText1)
        val texto2 = <EditText>(R.id.editText2)

    }
}